document.addEventListener('DOMContentLoaded', () => {
    const options = document.querySelectorAll('.option');
    let selectedProfile = 'focus';

    options.forEach(option => {
        option.addEventListener('click', () => {
            options.forEach(o => {
                o.classList.remove('active');
                o.setAttribute('aria-checked', 'false');
            });
            option.classList.add('active');
            option.setAttribute('aria-checked', 'true');
            selectedProfile = option.dataset.profile;
        });
        
        // Allow keyboard selection (Accessibility)
        option.addEventListener('keypress', (e) => {
            if(e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                option.click();
            }
        });
    });

    document.getElementById('finish-btn').addEventListener('click', () => {
        let settings = { presetMode: selectedProfile };
        
        // Define default configurations based on choice (mirroring popup.js logic)
        if (selectedProfile === 'focus') {
            settings.bionicEnabled = true;
            settings.lineSpacing = "1.8";
            settings.bgColor = "#E0F4FF";
            settings.fontSize = "default";
            settings.fontFamily = "'Lexend', sans-serif";
            settings.textColor = "default";
        } else if (selectedProfile === 'easier') {
            settings.fontFamily = "Arial, sans-serif";
            settings.fontSize = "22px";
            settings.lineSpacing = "1.8";
            settings.bionicEnabled = false;
            settings.bgColor = "#FDF6E3";
            settings.textColor = "#1A202C";
        } else if (selectedProfile === 'listen') {
            settings.ttsEnabled = true;
            settings.ttsSpeed = "0.7";
            settings.lineSpacing = "2.0";
        }

        settings.onboardingComplete = true;

        chrome.storage.sync.set(settings, () => {
            alert("Setup complete! You can now use the Web Transformer from your toolbar.");
            window.close(); // Close the tab
        });
    });
});
